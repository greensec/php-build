/* A Bison parser, made by GNU Bison 3.7.5.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_INI_TMP_PHPBUILD_POT42P_SEC_SRC_ZEND_ZEND_INI_PARSER_H_INCLUDED
# define YY_INI_TMP_PHPBUILD_POT42P_SEC_SRC_ZEND_ZEND_INI_PARSER_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int ini_debug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    END = 0,                       /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TC_SECTION = 258,              /* TC_SECTION  */
    TC_RAW = 259,                  /* TC_RAW  */
    TC_CONSTANT = 260,             /* TC_CONSTANT  */
    TC_NUMBER = 261,               /* TC_NUMBER  */
    TC_STRING = 262,               /* TC_STRING  */
    TC_WHITESPACE = 263,           /* TC_WHITESPACE  */
    TC_LABEL = 264,                /* TC_LABEL  */
    TC_OFFSET = 265,               /* TC_OFFSET  */
    TC_DOLLAR_CURLY = 266,         /* TC_DOLLAR_CURLY  */
    TC_VARNAME = 267,              /* TC_VARNAME  */
    TC_QUOTED_STRING = 268,        /* TC_QUOTED_STRING  */
    BOOL_TRUE = 269,               /* BOOL_TRUE  */
    BOOL_FALSE = 270,              /* BOOL_FALSE  */
    NULL_NULL = 271,               /* NULL_NULL  */
    END_OF_LINE = 272              /* END_OF_LINE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int ini_parse (void);

#endif /* !YY_INI_TMP_PHPBUILD_POT42P_SEC_SRC_ZEND_ZEND_INI_PARSER_H_INCLUDED  */
