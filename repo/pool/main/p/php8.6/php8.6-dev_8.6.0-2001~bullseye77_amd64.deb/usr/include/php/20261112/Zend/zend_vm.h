/*
   +----------------------------------------------------------------------+
   | Zend Engine                                                          |
   +----------------------------------------------------------------------+
   | Copyright © Zend Technologies Ltd., a subsidiary company of          |
   |     Perforce Software, Inc., and Contributors.                       |
   +----------------------------------------------------------------------+
   | This source file is subject to the Modified BSD License that is      |
   | bundled with this package in the file LICENSE, and is available      |
   | through the World Wide Web at <https://www.php.net/license/>.        |
   |                                                                      |
   | SPDX-License-Identifier: BSD-3-Clause                                |
   +----------------------------------------------------------------------+
   | Authors: Dmitry Stogov <dmitry@php.net>                              |
   +----------------------------------------------------------------------+
*/

#ifndef ZEND_VM_H
#define ZEND_VM_H

#include "zend_portability.h"

typedef struct _zend_op zend_op;
typedef struct _zend_execute_data zend_execute_data;

BEGIN_EXTERN_C()

ZEND_API void ZEND_FASTCALL zend_vm_set_opcode_handler(zend_op* opcode);
ZEND_API void ZEND_FASTCALL zend_vm_set_opcode_handler_ex(zend_op* opcode, uint32_t op1_info, uint32_t op2_info, uint32_t res_info);
ZEND_API void ZEND_FASTCALL zend_serialize_opcode_handler(zend_op *op);
ZEND_API void ZEND_FASTCALL zend_deserialize_opcode_handler(zend_op *op);
ZEND_API const void* ZEND_FASTCALL zend_get_opcode_handler_func(const zend_op *op);
ZEND_API const zend_op *zend_get_halt_op(void);
ZEND_API const zend_op *zend_get_interrupt_op(void);
ZEND_API int ZEND_FASTCALL zend_vm_call_opcode_handler(zend_execute_data *ex);
ZEND_API int zend_vm_kind(void);
ZEND_API bool zend_gcc_global_regs(void);

void zend_vm_init(void);
void zend_vm_dtor(void);

#if ZEND_VM_KIND == ZEND_VM_KIND_TAILCALL
const struct _zend_op *ZEND_FASTCALL zend_vm_handle_interrupt(struct _zend_execute_data *execute_data, const struct _zend_op *opline);
#endif

END_EXTERN_C()

#define ZEND_VM_SET_OPCODE_HANDLER(opline) zend_vm_set_opcode_handler(opline)

#endif
