/*
   +----------------------------------------------------------------------+
   | Copyright © The PHP Group and Contributors.                          |
   +----------------------------------------------------------------------+
   | This source file is subject to the Modified BSD License that is      |
   | bundled with this package in the file LICENSE, and is available      |
   | through the World Wide Web at <https://www.php.net/license/>.        |
   |                                                                      |
   | SPDX-License-Identifier: BSD-3-Clause                                |
   +----------------------------------------------------------------------+
   | Author: Sara Golemon <pollita@php.net>                               |
   +----------------------------------------------------------------------+
*/

#ifndef PHP_HASH_SHA3_H
#define PHP_HASH_SHA3_H

typedef struct {
#ifdef HAVE_SLOW_HASH3
	unsigned char state[200]; // 5 * 5 * sizeof(uint64)
	uint32_t pos;
#else
	unsigned char state[224]; // this must fit a Keccak_HashInstance
#endif
} PHP_SHA3_CTX;
#ifdef HAVE_SLOW_HASH3
#define PHP_SHA3_SPEC "b200l."
#endif

typedef PHP_SHA3_CTX PHP_SHA3_224_CTX;
typedef PHP_SHA3_CTX PHP_SHA3_256_CTX;
typedef PHP_SHA3_CTX PHP_SHA3_384_CTX;
typedef PHP_SHA3_CTX PHP_SHA3_512_CTX;

PHP_HASH_API void PHP_SHA3224Init(PHP_SHA3_224_CTX*, ZEND_ATTRIBUTE_UNUSED HashTable *);
PHP_HASH_API void PHP_SHA3224Update(PHP_SHA3_224_CTX*, const unsigned char*, size_t);
PHP_HASH_API void PHP_SAH3224Final(unsigned char[32], PHP_SHA3_224_CTX*);

PHP_HASH_API void PHP_SHA3256Init(PHP_SHA3_256_CTX*, ZEND_ATTRIBUTE_UNUSED HashTable *);
PHP_HASH_API void PHP_SHA3256Update(PHP_SHA3_256_CTX*, const unsigned char*, size_t);
PHP_HASH_API void PHP_SAH3256Final(unsigned char[32], PHP_SHA3_256_CTX*);

PHP_HASH_API void PHP_SHA3384Init(PHP_SHA3_384_CTX*, ZEND_ATTRIBUTE_UNUSED HashTable *);
PHP_HASH_API void PHP_SHA3384Update(PHP_SHA3_384_CTX*, const unsigned char*, size_t);
PHP_HASH_API void PHP_SAH3384Final(unsigned char[32], PHP_SHA3_384_CTX*);

PHP_HASH_API void PHP_SHA3512Init(PHP_SHA3_512_CTX*, ZEND_ATTRIBUTE_UNUSED HashTable *);
PHP_HASH_API void PHP_SHA3512Update(PHP_SHA3_512_CTX*, const unsigned char*, size_t);
PHP_HASH_API void PHP_SAH3512Final(unsigned char[32], PHP_SHA3_512_CTX*);

#endif
