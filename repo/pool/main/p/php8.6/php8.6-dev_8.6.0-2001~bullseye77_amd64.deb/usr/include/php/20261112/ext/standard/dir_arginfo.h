/* This is a generated file, edit dir.stub.php instead.
 * Stub hash: e21d382cd4001001874c49d8c5244efb57613910 */

#include "zend_constants.h"

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_Directory_close, 0, 0, IS_VOID, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_Directory_rewind arginfo_class_Directory_close

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_MASK_EX(arginfo_class_Directory_read, 0, 0, MAY_BE_STRING|MAY_BE_FALSE)
ZEND_END_ARG_INFO()

ZEND_METHOD(Directory, close);
ZEND_METHOD(Directory, rewind);
ZEND_METHOD(Directory, read);

static const zend_function_entry class_Directory_methods[] = {
	ZEND_ME(Directory, close, arginfo_class_Directory_close, ZEND_ACC_PUBLIC)
	ZEND_ME(Directory, rewind, arginfo_class_Directory_rewind, ZEND_ACC_PUBLIC)
	ZEND_ME(Directory, read, arginfo_class_Directory_read, ZEND_ACC_PUBLIC)
	ZEND_FE_END
};

static void register_dir_symbols(int module_number)
{
	REGISTER_STRING_CONSTANT("DIRECTORY_SEPARATOR", dirsep_str, CONST_PERSISTENT);
	REGISTER_STRING_CONSTANT("PATH_SEPARATOR", pathsep_str, CONST_PERSISTENT);
#if (defined(PHP_GLOB_BRACE) && PHP_GLOB_BRACE != 0)
	REGISTER_LONG_CONSTANT("GLOB_BRACE", PHP_GLOB_BRACE, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_ERR) && PHP_GLOB_ERR != 0)
	REGISTER_LONG_CONSTANT("GLOB_ERR", PHP_GLOB_ERR, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_MARK) && PHP_GLOB_MARK != 0)
	REGISTER_LONG_CONSTANT("GLOB_MARK", PHP_GLOB_MARK, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_NOCHECK) && PHP_GLOB_NOCHECK != 0)
	REGISTER_LONG_CONSTANT("GLOB_NOCHECK", PHP_GLOB_NOCHECK, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_NOESCAPE) && PHP_GLOB_NOESCAPE != 0)
	REGISTER_LONG_CONSTANT("GLOB_NOESCAPE", PHP_GLOB_NOESCAPE, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_NOSORT) && PHP_GLOB_NOSORT != 0)
	REGISTER_LONG_CONSTANT("GLOB_NOSORT", PHP_GLOB_NOSORT, CONST_PERSISTENT);
#endif
#if (defined(PHP_GLOB_ONLYDIR) && PHP_GLOB_ONLYDIR != 0)
	REGISTER_LONG_CONSTANT("GLOB_ONLYDIR", PHP_GLOB_ONLYDIR, CONST_PERSISTENT);
#endif
#if defined(PHP_GLOB_AVAILABLE_FLAGS)
	REGISTER_LONG_CONSTANT("GLOB_AVAILABLE_FLAGS", PHP_GLOB_AVAILABLE_FLAGS, CONST_PERSISTENT);
#endif
	REGISTER_LONG_CONSTANT("SCANDIR_SORT_ASCENDING", PHP_SCANDIR_SORT_ASCENDING, CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("SCANDIR_SORT_DESCENDING", PHP_SCANDIR_SORT_DESCENDING, CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("SCANDIR_SORT_NONE", PHP_SCANDIR_SORT_NONE, CONST_PERSISTENT);
}

static zend_class_entry *register_class_Directory(void)
{
	zend_class_entry ce, *class_entry;

	INIT_CLASS_ENTRY(ce, "Directory", class_Directory_methods);
	class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_FINAL|ZEND_ACC_NO_DYNAMIC_PROPERTIES|ZEND_ACC_NOT_SERIALIZABLE);

	zval property_path_default_value;
	ZVAL_UNDEF(&property_path_default_value);
	zend_declare_typed_property(class_entry, ZSTR_KNOWN(ZEND_STR_PATH), &property_path_default_value, ZEND_ACC_PUBLIC|ZEND_ACC_READONLY, NULL, (zend_type) ZEND_TYPE_INIT_MASK(MAY_BE_STRING));

	zval property_handle_default_value;
	ZVAL_UNDEF(&property_handle_default_value);
	zend_string *property_handle_name = zend_string_init("handle", sizeof("handle") - 1, true);
	zend_declare_typed_property(class_entry, property_handle_name, &property_handle_default_value, ZEND_ACC_PUBLIC|ZEND_ACC_READONLY, NULL, (zend_type) ZEND_TYPE_INIT_MASK(MAY_BE_ANY));
	zend_string_release_ex(property_handle_name, true);

	return class_entry;
}
